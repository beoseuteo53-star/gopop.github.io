# GoPop V2

### 초기 설정:

윈도우:

```bat
setup.bat
```

리눅스:

```sh
. setup.sh
```

### 실행:

윈도우:

```bat
start.bat
```

리눅스:

```sh
. start.sh
```
