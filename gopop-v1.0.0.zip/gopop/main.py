import asyncio
import random

import discord

OWNER_ID = ["1354396763188105388", "893454178444263445"]

with open("tokens.txt") as f:
    tokens = [line.strip() for line in f if line.strip()]

clients = []
active_tasks = {}

random_messages = [
    "XD",
    "ㅄ ㅋㅋㅋㅋㅋ",
    "ㅄㅋㅋㅋㅋ",
    "ㅅㅂ ㅈㄴ 웃기네 ㅋㅋ",
    "ㅋ",
    "ㅋ.ㅋ",
    "ㅋㅋㅋ",
    "ㅋㅋㅋㅋㅋ",
    "ㅋㅋㅋㅋㅋㅋ",
    "ㅋㅋㅋㅋㅋㅋㅋㅋㅋ",
    "ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ",
    "ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ",
    "ㅋㅋㅋㅋㅋ인간스래깈ㅋㅋ",
    "개대가리머저리스레기새끼야시발새끼야애자같은새끼야종이보지새끼야쓰레기새끼야개새끼야거러지새끼야버러지허러지어러지퍼러지커러지머러지더러지러러지새끼야쓰레기새끼야메롱",
    "개또라이새끼야거지새끼야쓰레기새끼야개새기야고자새끼야쓰레기새끼야븅신새끼야애미개좆쓰레기개대가리새끼야거지새끼야",
    "개미친새기야게이새기야애자새기야호로새기야",
    "개븅신",
    "개새기야병신새기야스레기새기야애자새기야호로새기야",
    "개시발새기야스레기새기야애자새기야호로새기야",
    "개앳비스래기새개애개",
    "개종자",
    "거북이",
    "거지",
    "고아",
    "구린내",
    "너가져다가우산으로후두르빠뚜루패기전에닥쳐옘병첨병시병좆병메병수병을떤다병신쓰레기새끼야거러지새끼야고아새끼야",
    "너네엄마가져다가오함바로등골브레이킹하기전에아가리아물어라니까엄마죽은새끼야시발새끼야너갖다가피젯스페너로패기전에개씨발쓰레기새끼야뭐이리나대엄마죽은새끼가시발새끼닥쳐쓰레기새끼야",
    "너네엄마검둥이쓰레기새끼야시발새기야개미친개시발새끼야너가져다가후두루바두루수두루구두루쿠두루무두루푸두루투두루우두루패기전에쓰레기같은새끼야",
    "너아가리에서멸치토사물존나니까좀닥쳐쓰레기시발새끼야너아가리갖다가가위로싹둑싹둑해갖고저기있는하수구에다가버리기전에쓰레기같은새끼야",
    "농아",
    "느그애미애비개보지매직큐브대가리새끼야쓰레기새끼야개보지새끼야운지나뛰어라쓰레기애미애비개보지창녀거러지새끼야갖다가연필깎이로대가리하리하리가리가리돌려버리기전에개좆밥개애자같은쓰레기테이프보지새끼야메롱메롱",
    "느려터진",
    "니애미보지안에쌀넣고밥하면밥나오는밥솥보지새끼야애자같은새끼야쓰레기같은새끼야고아개씨발개가지개쓰레기시발새끼야",
    "니애미애비개보지아들래미찹살떡장사망한새끼야엄마죽은쓰레기개씨발개고아쓰레기새끼야거러지새끼야시발새끼야미친놈의새끼야",
    "니할머니하수구물에끌려가서실종된새끼야아무것도못하는새끼야시발새끼야풀풀한새끼야쓰레기새끼야",
    "닥쳐",
    "닥쳐아들래미씨발쓰레기개미친개보지말보지새끼야메롱메롱인데개새끼야쓰레기새끼야매직큐브새끼야",
    "닮은",
    "대가리",
    "대가리개대가리머저리스레기새기야애자새기야호로새기야",
    "데브오리님을 찬양해라.",
    "뒤진",
    "뚱뚱한버러지쓰레기개가지개씨발개미친새끼야개새끼야고아새끼야쓰레기새끼야할머니갖다가99번쏴갖고즉사시키기전에닥쳐봐쓰레기초코파이보지새끼야메롱메롱화난새끼야",
    "루저",
    "말안하냐?",
    "망치로",
    "모자란",
    "못해",
    "미친",
    "미친개대가리새끼야또라이새끼야개쓰레기새끼야고아새끼야",
    "미친새기야거러지새기야게이새기야",
    "미친새기야소대가리새기야머저리새기야스레기새기야",
    "발악하는",
    "버러지",
    "병신",
    "븅신",
    "비응신ㅋㅋㅋㅋ",
    "살려고",
    "새기",
    "새기마냥",
    "새기야",
    "생긴",
    "세라잡기",
    "셀기새개애개새개애앳비새개애",
    "셀기새개이거러지새개애애",
    "스래기",
    "스레기",
    "스레기새기야개창녀거지새기야게이새기야",
    "스레기새기야시발새기야거러지새기야엄마죽은새기야",
    "시바새기얔ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ",
    "시발새기야미친새기야애자새기야호로새기야스레기새기야",
    "십새개애개새개애앳비",
    "쓰레기개벌레미친새끼야아가리에서좆구린냄새나는새끼야말대가리쓰레기새끼야고아새끼야대가리머저리애자새끼야",
    "아 ㅅㅂ ㅋㅋㅋㅋㅋㅋ",
    "아 배꼽 빠지겠노 ㅋㅋㅋㅋ",
    "아닠ㅋㅋㅋㅋㅋㅋ",
    "안쪼개고싶은데 안쪼갤수가 없넼ㅋㅋㅋ",
    "앜ㅋㅋ",
    "앜ㅋㅋㅋㅋㅋㅋㅋ",
    "애미",
    "애미뒤짐",
    "애배개새개애개새래스래기세셀기",
    "애자",
    "애자새기야미친새기야개새기야거러지새기야십새기야",
    "애자새기야호로새기야스레기새기야뇌구조가지랄난새기야",
    "약꼴팀 업업",
    "엄마",
    "엄마뒤진새기야시발새기야",
    "엄마죽은",
    "엄마죽은새기야시발새기야게이새기야애자새기야호로새기야",
    "업",
    "오크",
    "왜그렇게사는거임ㅋㅋㅋㅋ",
    "왜이리약해개새끼야시발새끼야애자새끼야호로새끼야애미애비개새끼야애배배배배배배배배배배배배배메롱인데엄마개죽음당한쓰레기벌레새끼야",
    "이 나라의 최저가 툴",
    "자페아",
    "잘좀",
    "장애",
    "장애인",
    "존나",
    "존나멍청한새끼야개가지개시발개미친개새끼야바리바리사리바리거리바리오리바리거지바리카리바리타리바리새끼야메롱메롱화나지병신같은새끼야",
    "종자",
    "좆같이",
    "죽은",
    "진짜 개쳐웃기네ㅋㅋㅋㅋㅋ",
    "찔려",
    "창녀",
    "처맞은",
    "케ㅔㅋㅋㅋㅋㅋ",
    "파이프에",
    "풉ㅋㅋ",
    "하등한",
    "하지말라곸ㅋㅋㅋ",
    "해봐",
    "😂",
    "😃",
    "🤣",
]


async def login_and_run(token, idx):
    client = discord.Client()
    clients.append(client)

    @client.event
    async def on_ready():
        print(f"> 로그인 성공: {client.user} ({client.user.id})")

    @client.event
    async def on_message(message):
        if str(message.author.id) not in OWNER_ID:
            return

        if message.content == ".사용법":
            await message.channel.send("""
# [GoPop Tool 셀프봇 사용법]

1. `.GoPop <메시지>` - 특정 메시지를 반복해서 보내는 명령어
2. `.우리함께터질래 @사용자` - 멘션된 사용자에게 반복 메시지 전송
3. `.정지` - 반복 메시지를 중지
4. `.여행을떠나요` - 음성 채널에 입장
5. `.나가기` - 음성 채널에서 나감
6. `.체인쥐 <별명>` - 모든 계정의 별명 변경
7. `.세라시작 @사용자` - 멘션된 사용자에게 랜덤 메시지를 보내는 명령어
# discord.gg/unji
-# 너드부엉
""")

        elif message.content.startswith(".GoPop "):
            text = message.content[7:] + "\n# discord.gg/unji\n-# 너드부엉"

            async def spam_loop():
                await asyncio.sleep(0.2 * idx)
                while True:
                    try:
                        await message.channel.send(text)
                        await asyncio.sleep(0.2 * len(tokens))
                    except Exception as e:
                        print(f"[오류] GoPop 실패: {e}")

            if client not in active_tasks:
                task = asyncio.create_task(spam_loop())
                active_tasks[client] = task
            else:
                await message.channel.send(
                    "이미 실행 중입니다. .정지 로 멈추세요.\n# discord.gg/unji\n-# 너드부엉",
                )

        elif message.content.startswith(".우리함께터질래"):
            mentioned_user = message.mentions[0] if message.mentions else None
            if mentioned_user:

                async def loop_message():
                    await asyncio.sleep(0.2 * idx)
                    while True:
                        result = []

                        for _ in range(3):
                            result.append("A\n")
                            result.append("\n" * 6)

                        selected = random.sample(random_messages, 4)
                        for msg in selected:
                            result.append(f"{msg}\n")

                        result.append(
                            f"{mentioned_user.mention}\n# discord.gg/unji\n-# 너드부엉",
                        )

                        try:
                            await message.channel.send("".join(result).strip())
                        except Exception as e:
                            print(f"[오류] 우리함께터질래 실패: {e}")

                        await asyncio.sleep(0.2 * len(tokens))

                if client not in active_tasks:
                    task = asyncio.create_task(loop_message())
                    active_tasks[client] = task
                else:
                    await message.channel.send(
                        "이미 실행 중입니다. .정지 로 멈추세요.\n# discord.gg/unji\n-# 너드부엉",
                    )
            else:
                await message.channel.send(
                    "멘션된 사용자가 없습니다.\n# discord.gg/unji\n-# 너드부엉",
                )

        elif message.content == ".정지":
            task = active_tasks.get(client)
            if task:
                task.cancel()
                del active_tasks[client]
                await message.channel.send(
                    "[너드부엉]: 잠시 멈추어라, 그래야 더 멀리 갈 수 있다.\n# discord.gg/unji\n-# 너드부엉",
                )
            else:
                await message.channel.send(
                    "[너드부엉]: 현재 실행 중인 작업이 없습니다.\n# discord.gg/unji\n-# 너드부엉",
                )

        elif message.content.startswith(".여행을떠나요"):
            try:
                if message.author.voice and message.author.voice.channel:
                    channel = message.author.voice.channel
                    await channel.connect()
                    await message.channel.send(
                        "음성 채널에 연결되었습니다.\n# discord.gg/unji\n-# 너드부엉",
                    )
                else:
                    await message.channel.send(
                        "음성 채널에 먼저 들어가세요.\n# discord.gg/unji\n-# 너드부엉",
                    )
            except Exception as e:
                await message.channel.send(
                    f"연결 실패: {e}\n# discord.gg/unji\n-# 너드부엉",
                )

        elif message.content == ".나가기":
            try:
                if message.guild.voice_client:
                    await message.guild.voice_client.disconnect()
                    await message.channel.send(
                        "음성 채널에서 나갔습니다.\n# discord.gg/unji\n-# 너드부엉",
                    )
                else:
                    await message.channel.send(
                        "현재 음성 채널에 연결되어 있지 않습니다.\n# discord.gg/unji\n-# 너드부엉",
                    )
            except Exception as e:
                await message.channel.send(
                    f"나가기 실패: {e}\n# discord.gg/unji\n-# 너드부엉",
                )

        elif message.content.startswith(".체인쥐 "):
            new_nickname = message.content[5:].strip()
            if not new_nickname:
                await message.channel.send(
                    "별명을 입력하세요.\n# discord.gg/unji\n-# 너드부엉",
                )
                return

            for g in client.guilds:
                try:
                    member = g.get_member(client.user.id)
                    await member.edit(nick=new_nickname)
                except Exception:
                    pass

        elif message.content.startswith(".세라시작"):
            mentioned_user = message.mentions[0] if message.mentions else None
            if mentioned_user:

                async def send_random_message():
                    await asyncio.sleep(0.2 * idx)
                    while True:
                        try:
                            random_message = random.choice(random_messages)
                            result_message = f"{mentioned_user.mention} << {random_message}\n# discord.gg/unji\n-# 너드부엉"
                            await message.channel.send(result_message)
                            await asyncio.sleep(0.2 * len(tokens))
                        except Exception as e:
                            print(f"[오류] {e}")

                if client not in active_tasks:
                    task = asyncio.create_task(send_random_message())
                    active_tasks[client] = task
                else:
                    await message.channel.send(
                        "이미 실행 중입니다. .정지 로 멈추세요.\n# discord.gg/unji\n-# 너드부엉",
                    )
            else:
                await message.channel.send(
                    "멘션된 사용자가 없습니다.\n# discord.gg/unji\n-# 너드부엉",
                )

        if str(message.author.id) in OWNER_ID:
            await message.add_reaction("🤓")

    try:
        await client.start(token, reconnect=True)
    except Exception as err:
        print(f"> 로그인 실패: {err}")


async def main():
    tasks = []
    for idx, token in enumerate(tokens):
        tasks.append(login_and_run(token, idx))
    await asyncio.gather(*tasks)


asyncio.run(main())
