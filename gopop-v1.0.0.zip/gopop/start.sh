#!/bin/sh

uv run main.py
read
